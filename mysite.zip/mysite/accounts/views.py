from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm

def index(request):
    # returns accounts/index.html (must be in accounts/templates/accounts/index.html)
    return render(request, 'accounts/index.html')

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')   # django.contrib.auth.urls provides 'login' view name
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})
